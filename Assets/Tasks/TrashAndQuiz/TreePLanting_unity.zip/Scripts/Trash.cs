using UnityEngine;

public class Trash : MonoBehaviour
{
    public string question;
    public string answer;
    public bool isCollected = false;  // Track if the trash is already collected
}
